document.addEventListener('DOMContentLoaded', function () {
    const instansiForm = document.querySelector('#instansiForm');
    const userForm = document.querySelector('#userForm');

    if (instansiForm) {
        instansiForm.addEventListener('submit', function (e) {
            e.preventDefault();
            alert('Pengaturan Instansi berhasil disimpan.');
        });
    }

    if (userForm) {
        userForm.addEventListener('submit', function (e) {
            e.preventDefault();
            alert('Pengaturan User berhasil disimpan.');
        });
    }
});