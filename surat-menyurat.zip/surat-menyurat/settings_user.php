<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "web_uap";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $email = $_POST['email'];

    $check_query = "SELECT * FROM tbl_users WHERE username = ?";
    $stmt_check = $conn->prepare($check_query);
    $stmt_check->bind_param("s", $username);
    $stmt_check->execute();
    $result_check = $stmt_check->get_result();

    if ($result_check->num_rows > 0) {
        $registration_error = "Error: Username sudah ada dalam database.";
    } 
    else {
        $insert_query = "INSERT INTO tbl_users (username, password, email) VALUES (?, ?, ?)";
        $stmt_insert = $conn->prepare($insert_query);
        $stmt_insert->bind_param("sss", $username, $password, $email);

        if ($stmt_insert->execute()) {
            $registration_message = "Registrasi berhasil!";
        } 
        else {
            $registration_error = "Error: " . $insert_query . "<br>" . $conn->error;
        }
        $stmt_insert->close();
    }
    $stmt_check->close();
}
$sql = "SELECT * FROM tbl_users";
$result = $conn->query($sql);
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pengaturan User - Pengelolaan Surat</title>
    <link rel="stylesheet" href="css/materialize.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        .container {
            max-width: 800px;
            margin: 0 auto;
        }

        .input-field {
            margin-bottom: 1rem;
        }

        .input-field label {
            display: block;
            margin-bottom: 0.5rem;
            color: #666;
        }

        .input-field input {
            width: 100%;
            padding: 0.5rem;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .btn {
            background: #007BFF;
            color: #fff;
            padding: 0.75rem 1rem;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            width: 100%;
            text-align: center;
        }

        .btn:hover {
            background: #0056b3;
        }

        .btn-danger {
            background-color: #f44336;
        }

        .btn-sm {
            padding: 0.25rem 0.5rem;
        }

        .error {
            color: #f44336;
            margin-top: 1rem;
        }

        .card {
            background-color: #fff;
            padding: 1rem;
            margin: 1rem 0;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .table .btn {
            margin-right: 5px;
        }

        .action-buttons {
            display: flex;
            align-items: center;
        }
    </style>
</head>
<body>
    <!-- Bootstrap Header -->
    <header>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
            <a class="navbar-brand d-flex align-items-center" href="dashboard.html">
                <img src="assets/img/logo.png" alt="Logo" class="navbar-logo"> PS
            </a>
            <span class="navbar-divider"></span>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item"><a class="nav-link" href="dashboard.php">Beranda</a></li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="transaksiSuratDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Transaksi Surat</a>
                        <div class="dropdown-menu" aria-labelledby="transaksiSuratDropdown">
                            <a class="dropdown-item" href="surat_masuk.php">Surat Masuk</a>
                            <a class="dropdown-item" href="surat_keluar.php">Surat Keluar</a>
                        </div>
                    </li>
                    <li class="nav-item"><a class="nav-link" href="buku_agenda.php">Buku Agenda</a></li>
                    <li class="nav-item"><a class="nav-link" href="galeri_file.php">Galeri File</a></li>
                    <li class="nav-item"><a class="nav-link" href="referensi.php">Referensi</a></li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="pengaturanDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Pengaturan</a>
                        <div class="dropdown-menu" aria-labelledby="pengaturanDropdown">
                            <a class="dropdown-item" href="settings_user.php">User</a>
                        </div>
                    </li>
                </ul>
                <div class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="profilDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <img src="assets/img/iconmonstr-user-5.svg" alt="Profile" class="profile-img"> Administrator
                    </a>
                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="profilDropdown">
                        <a class="dropdown-item" href="administrator.php">Profile</a>
                        <a class="dropdown-item" href="login.php">Logout</a>
                    </div>
                </div>
            </div>
        </nav>
    </header>

    <main class="container mt-4">
        <section class="settings">
            <h2>Pengaturan User</h2>
            <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <div class="input-field">
                    <label for="username"><b>Username</b></label>
                    <input type="text" placeholder="Masukkan Username" name="username" required>
                </div>
                <div class="input-field">
                    <label for="password"><b>Password</b></label>
                    <input type="password" placeholder="Masukkan Password" name="password" required>
                </div>
                <div class="input-field">
                    <label for="email"><b>Email</b></label>
                    <input type="email" placeholder="Masukkan Email" name="email" required>
                </div>
                <button type="submit" class="btn">Simpan</button>
            </form>
            <?php if (isset($registration_message)) { ?>
                <div class="alert alert-success mt-3" role="alert">
                    <?php echo $registration_message; ?>
                </div>
            <?php } ?>
            <?php if (isset($registration_error)) { ?>
                <div class="alert alert-danger mt-3" role="alert">
                    <?php echo $registration_error; ?>
                </div>
            <?php } ?>
        </section>
        <section>
              <h3>Daftar Pengguna</h3>
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>" . $row["id"] . "</td>";
                            echo "<td>" . $row["username"] . "</td>";
                            echo "<td>" . $row["email"] . "</td>";
                            echo "<td>";
                            echo "<a href='edit_user.php?id=" . $row["id"] . "' class='btn btn-primary btn-sm'>Edit</a>";
                            echo "<a href='delete_user.php?id=" . $row["id"] . "' class='btn btn-danger btn-sm ml-1' onclick='return confirmDelete()'>Hapus</a>";
                            echo "</td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='4'>Tidak ada pengguna</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </section>

    </main>
    <footer>
        <div class="card footer-card mt-4">
            <h5 class="card-header">Pengelolaan Surat</h5>
            <div class="card-body">
                <h5 class="card-title">Selamat Datang</h5>
                <p>&copy; 2024 Universitas Lampung || Letter Head</p>
                <p class="text-card">Kelola surat menyurat Anda dengan mudah dan efisien.</p>
                <a href="#" class="btn btn-primary">Pelajari Lebih Lanjut</a>
            </div>
        </div>
    </footer>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="js/settings.js"></script>

    <script>
        function confirmDelete() {
            return confirm('Apakah Anda yakin ingin menghapus pengguna ini?');
        }
    </script>
</body>
</html>
<?php
$conn->close();
?>