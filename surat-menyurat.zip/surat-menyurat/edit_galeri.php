<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "web_uap";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

$nama_file = $deskripsi = $file_path = ""; 

if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET["id"])) {
    $id = $_GET["id"];

    $sql = "SELECT * FROM tbl_galeri WHERE id = $id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $nama_file = $row["nama_file"];
        $deskripsi = $row["deskripsi"];
        $file_path = $row["file_path"];
    } else {
        echo "Data tidak ditemukan.";
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST["id"];
    $nama_file = $_POST["namaFile"];
    $deskripsi = $_POST["deskripsi"];

    $sql = "UPDATE tbl_galeri SET nama_file='$nama_file', deskripsi='$deskripsi' WHERE id=$id";

    if ($conn->query($sql) === TRUE) {
        echo "Data berhasil diupdate.";
    } else {
        echo "Error updating record: " . $conn->error;
    }

    header("Location: galeri_file.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit File - Pengelolaan Surat</title>
    <link rel="stylesheet" href="css/materialize.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <h2>Edit File</h2>
        <form action="edit_galeri.php" method="post"> 
            <input type="hidden" name="id" value="<?php echo $id; ?>">
            <div class="form-group">
                <label for="namaFile">Nama File:</label>
                <input type="text" class="form-control" id="namaFile" name="namaFile" value="<?php echo $nama_file; ?>">
            </div>
            <div class="form-group">
                <label for="deskripsi">Deskripsi:</label>
                <input type="text" class="form-control" id="deskripsi" name="deskripsi" value="<?php echo $deskripsi; ?>">
            </div>
            <div class="form-group">
                <label for="file">File:</label>
                <p><?php echo $file_path; ?></p> 
            </div>
            <button type="submit" class="btn btn-primary">Simpan</button>
        </form>
    </div>
</body>
</html>
<?php
$conn->close();
?>