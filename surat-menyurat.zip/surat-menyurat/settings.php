<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pengaturan - Pengelolaan Surat</title>
    <link rel="stylesheet" href="css/materialize.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <!-- Bootstrap Header -->
    <header>
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
            <a class="navbar-brand d-flex align-items-center" href="dashboard.html">
                <img src="assets/img/logo.png" alt="Logo" class="navbar-logo"> PS
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item"><a class="nav-link" href="dashboard.html">Beranda</a></li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="transaksiSuratDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Transaksi Surat</a>
                        <div class="dropdown-menu" aria-labelledby="transaksiSuratDropdown">
                            <a class="dropdown-item" href="surat_masuk.html">Surat Masuk</a>
                            <a class="dropdown-item" href="surat_keluar.html">Surat Keluar</a>
                        </div>
                    </li>
                    <li class="nav-item"><a class="nav-link" href="buku_agenda.html">Buku Agenda</a></li>
                    <li class="nav-item"><a class="nav-link" href="galeri_file.html">Galeri File</a></li>
                    <li class="nav-item"><a class="nav-link" href="referensi.html">Referensi</a></li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="pengaturanDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Pengaturan</a>
                        <div class="dropdown-menu" aria-labelledby="pengaturanDropdown">
                            <a class="dropdown-item" href="settings_user.html">User</a>
                        </div>
                    </li>
                </ul>
                <div class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="profilDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <img src="assets/img/iconmonstr-user-5.svg" alt="Profile" class="profile-img"> Administrator
                    </a>
                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="profilDropdown">
                        <a class="dropdown-item" href="administrator.html">Profile</a>
                        <a class="dropdown-item" href="logout.html">Logout</a>
                    </div>
                </div>
            </div>
        </nav>
    </header>
    
    <main>
        <section class="settings">
            <h2>Pengaturan Instansi</h2>
            <form>
                <label for="instansi"><b>Nama Instansi</b></label>
                <input type="text" placeholder="Masukkan Nama Instansi" name="instansi" required>
                <label for="alamat"><b>Alamat</b></label>
                <input type="text" placeholder="Masukkan Alamat" name="alamat" required>
                <label for="telepon"><b>Telepon</b></label>
                <input type="text" placeholder="Masukkan Telepon" name="telepon" required>
                <button type="submit" class="btn">Simpan</button>
            </form>
        </section>
        <section class="settings">
            <h2>Pengaturan User</h2>
            <form>
                <label for="username"><b>Username</b></label>
                <input type="text" placeholder="Masukkan Username" name="username" required>
                <label for="password"><b>Password</b></label>
                <input type="password" placeholder="Masukkan Password" name="password" required>
                <button type="submit" class="btn">Simpan</button>
            </form>
        </section>
    </main>

    <!-- Bootstrap Footer  -->
    <footer>
        <div class="card footer-card">
            <h5 class="card-header">Pengelolaan Surat</h5>
            <div class="card-body">
                <h5 class="card-title">Selamat Datang</h5>
                <p>&copy; 2024 Universitas Lampung || Letter Head</p>
                <p class="text-card">Kelola surat menyurat Anda dengan mudah dan efisien.</p>
                <a href="#" class="btn btn-primary">Pelajari Lebih Lanjut</a>
            </div>
        </div>
    </footer>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>