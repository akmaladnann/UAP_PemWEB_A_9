<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "web_uap";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$nama_pengguna = $_POST['username'];
$email = $_POST['email'];
$kata_sandi = $_POST['password'];

if (!empty($nama_pengguna) && !empty($email) && !empty($kata_sandi)) {
    $sql = "INSERT INTO adminn (nama, email, rolee) VALUES ('$nama_pengguna', '$email', '$kata_sandi')";

    if ($conn->query($sql) === TRUE) {
        echo "Login berhasil";
        header("Location: dashboard.php");
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
} else {
    echo "Username/Email/Password tidak boleh kosong!";
}

$conn->close();
?>