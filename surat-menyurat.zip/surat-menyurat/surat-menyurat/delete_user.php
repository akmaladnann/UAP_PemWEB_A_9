<?php
// Koneksi ke database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "web_uap";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Konfirmasi penghapusan setelah pengguna menekan tombol "Ya"
if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET["id"]) && isset($_GET["confirm"]) && $_GET["confirm"] == "yes") {
    $id = $_GET["id"];

    // Hapus data dari database
    $sql = "DELETE FROM tbl_galeri WHERE id = $id";

    if ($conn->query($sql) === TRUE) {
        // Redirect kembali ke halaman galeri_file.php
        echo '<script>window.location.href = "galeri_file.php";</script>';
        exit;
    } else {
        echo "Error deleting record: " . $conn->error;
    }
}

$conn->close();
?>
