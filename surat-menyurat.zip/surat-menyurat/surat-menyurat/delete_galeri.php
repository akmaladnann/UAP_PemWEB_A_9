<?php
// Koneksi ke database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "web_uap";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Konfirmasi penghapusan setelah pengguna menekan tombol "Ya"
if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET["id"])) {
    $id = intval($_GET["id"]); // Pastikan id adalah integer

    // Hapus data dari database dengan prepared statement
    $stmt = $conn->prepare("DELETE FROM tbl_galeri WHERE id = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute() === TRUE) {
        // Redirect kembali ke halaman galeri_file.php
        echo '<script>window.location.href = "galeri_file.php";</script>';
        exit;
    } else {
        echo "Error deleting record: " . $stmt->error;
    }

    $stmt->close();
}

$conn->close();
?>
