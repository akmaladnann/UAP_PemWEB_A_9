<?php
// Lakukan koneksi ke database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "web_uap";

$conn = new mysqli($servername, $username, $password, $dbname);

// Periksa koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Ambil data pengguna berdasarkan id
$user = null;
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = "SELECT * FROM tbl_users WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
    }
    $stmt->close();
}

// Update data pengguna
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $email = $_POST['email'];

    $query = "UPDATE tbl_users SET username = ?, password = ?, email = ? WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("sssi", $username, $password, $email, $id);
    
    if ($stmt->execute()) {
        header("Location: settings_user.php");
        exit();
    } else {
        $update_error = "Error: " . $query . "<br>" . $conn->error;
    }
    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit User - Pengelolaan Surat</title>
    <link rel="stylesheet" href="css/materialize.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        .container {
            max-width: 800px;
            margin: 0 auto;
        }

        .input-field {
            margin-bottom: 1rem;
        }

        .input-field label {
            display: block;
            margin-bottom: 0.5rem;
            color: #666;
        }

        .input-field input {
            width: 100%;
            padding: 0.5rem;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .btn {
            background: #007BFF;
            color: #fff;
            padding: 0.75rem 1rem;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            width: 100%;
            text-align: center;
        }

        .btn:hover {
            background: #0056b3;
        }

        .error {
            color: #f44336;
            margin-top: 1rem;
        }

        .card {
            background-color: #fff;
            padding: 1rem;
            margin: 1rem 0;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>
<body>
    <main class="container mt-4">
        <section class="settings">
            <h2>Edit User</h2>
            <?php if ($user) { ?>
                <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                    <input type="hidden" name="id" value="<?php echo $user['id']; ?>">
                    <div class="input-field">
                        <label for="username"><b>Username</b></label>
                        <input type="text" name="username" value="<?php echo $user['username']; ?>" required>
                    </div>
                    <div class="input-field">
                        <label for="password"><b>Password</b></label>
                        <input type="password" name="password" value="<?php echo $user['password']; ?>" required>
                    </div>
                    <div class="input-field">
                        <label for="email"><b>Email</b></label>
                        <input type="email" name="email" value="<?php echo $user['email']; ?>" required>
                    </div>
                    <button type="submit" class="btn">Update</button>
                </form>
            <?php } else { ?>
                <div class="alert alert-danger" role="alert">
                    User not found.
                </div>
            <?php } ?>
            <?php if (isset($update_error)) { ?>
                <div class="alert alert-danger mt-3" role="alert">
                    <?php echo $update_error; ?>
                </div>
            <?php } ?>
        </section>
    </main>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
