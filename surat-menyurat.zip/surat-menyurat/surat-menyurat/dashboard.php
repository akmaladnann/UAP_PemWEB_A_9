<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "web_uap";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT COUNT(*) AS total FROM surat_yang_ditambah";
$result = $conn->query($sql);
$row = $result->fetch_assoc();
$total_surat_masuk = $row['total'];

$sql = "SELECT COUNT(*) AS total FROM surat_keluar_yang_ditambah";
$result = $conn->query($sql);
$row = $result->fetch_assoc();
$total_surat_keluar = $row['total'];

$sql = "SELECT COUNT(*) AS total FROM adminn";
$result = $conn->query($sql);
$row = $result->fetch_assoc();
$total_admin = $row['total'];

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Pengelolaan Surat</title>
    <link rel="stylesheet" href="css/materialize.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <!-- Bootstrap Header -->
    <header>
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
            <a class="navbar-brand d-flex align-items-center" href="dashboard.php">
                <img src="assets/img/logo.png" alt="Logo" class="navbar-logo"> PS
            </a>
            <span class="navbar-divider"></span>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item"><a class="nav-link" href="dashboard.php">Beranda</a></li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="transaksiSuratDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Transaksi Surat</a>
                        <div class="dropdown-menu" aria-labelledby="transaksiSuratDropdown">
                            <a class="dropdown-item" href="surat_masuk.php">Surat Masuk</a>
                            <a class="dropdown-item" href="surat_keluar.php">Surat Keluar</a>
                        </div>
                    </li>
                    <li class="nav-item"><a class="nav-link" href="buku_agenda.php">Buku Agenda</a></li>
                    <li class="nav-item"><a class="nav-link" href="galeri_file.php">Galeri File</a></li>
                    <li class="nav-item"><a class="nav-link" href="referensi.php">Referensi</a></li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="pengaturanDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Pengaturan</a>
                        <div class="dropdown-menu" aria-labelledby="pengaturanDropdown">
                            <a class="dropdown-item" href="settings_user.php">User</a>
                        </div>
                    </li>
                </ul>
                <div class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="profilDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <img src="assets/img/iconmonstr-user-5.svg" alt="Profile" class="profile-img"> Administrator
                    </a>
                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="profilDropdown">
                        <a class="dropdown-item" href="administrator.php">Profile</a>
                        <a class="dropdown-item" href="login.php">Logout</a>
                    </div>
                </div>
            </div>
        </nav>
    </header>

    <!-- Bootstrap Content  -->
    <main class="container mt-4">
        <section class="institution-info mb-4">
            <div class="card">
                <div class="card-body d-flex align-items-center">
                    <img src="assets/img/Logo_Unila.jpg" alt="Logo Unila" class="institution-logo">
                    <div class="institution-details ml-3">
                        <h3>Universitas Lampung</h3>
                        <p>Jl. Prof. Dr. Sumantri Brojonegoro No.1, Bandar Lampung</p>
                    </div>
                </div>
            </div>
        </section>
        <section class="welcome">
            <h2>Selamat Datang di Sistem Informasi Pengelolaan Surat</h2>
            <p>Ini adalah halaman beranda untuk Sistem Informasi Manajemen Surat Universitas Lampung.</p>
        </section>
        <section class="overview mt-4">
            <h2>Overview</h2>
            <div class="row">
                <div class="col-md-4">
                    <div class="card text-white bg-info mb-3">
                        <div class="card-body">
                            <h3 class="card-title">
                                <img src="assets/img/incoming-mail-user.svg" alt="Surat Masuk" class="icon"> Jumlah Surat Masuk
                            </h3>
                            <p class="card-text"><?php echo $total_surat_masuk; ?> Surat Masuk</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card text-white bg-success mb-3">
                        <div class="card-body">
                            <h3 class="card-title">
                                <img src="assets/img/outgoing-mail-user.svg" alt="Surat Keluar" class="icon"> Jumlah Surat Keluar
                            </h3>
                            <p class="card-text"><?php echo $total_surat_keluar; ?> Surat Keluar</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card text-white bg-warning mb-3">
                        <div class="card-body">
                            <h3 class="card-title">
                                <img src="assets/img/iconmonstr-disposition-user.svg" alt="Disposisi" class="icon"> Jumlah Disposisi
                            </h3>
                            <p class="card-text">0 Disposisi</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card text-white bg-danger mb-3">
                        <div class="card-body">
                            <h3 class="card-title">
                                <img src="assets/img/iconmonstr-classification_letter-user.svg" alt="Klasifikasi Surat" class="icon"> Jumlah Klasifikasi Surat
                            </h3>
                            <p class="card-text">2 Klasifikasi Surat</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card text-white bg-primary mb-3">
                        <div class="card-body">
                            <h3 class="card-title">
                                <img src="assets/img/iconmonstr-user-31.svg" alt="Pengguna" class="icon"> Jumlah Pengguna
                            </h3>
                            <p class="card-text"><?php echo $total_admin; ?> Pengguna</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <!-- Bootstrap Footer  -->
    <footer>
        <div class="card footer-card mt-4">
            <h5 class="card-header">Pengelolaan Surat</h5>
            <div class="card-body">
                <h5 class="card-title">Selamat Datang</h5>
                <p>&copy; 2024 Universitas Lampung || Letter Head</p>
                <p class="text-card">Kelola surat menyurat Anda dengan mudah dan efisien.</p>
                <a href="#" class="btn btn-primary">Pelajari Lebih Lanjut</a>
            </div>
        </div>
    </footer>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>