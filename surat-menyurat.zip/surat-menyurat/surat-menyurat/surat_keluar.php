<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Surat Keluar - Pengelolaan Surat</title>
    <link rel="stylesheet" href="css/materialize.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        .modal-confirm {
            display: none;
            position: fixed;
            z-index: 1;
            padding-top: 100px;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgb(0,0,0);
            background-color: rgba(0,0,0,0.4);
        }
        .modal-content-confirm {
            background-color: #fefefe;
            margin: auto;
            padding: 20px;
            border: 1px solid #888;
            width: 80%;
            max-width: 300px;
        }
        .close-confirm {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }
        .close-confirm:hover,
        .close-confirm:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <!-- Bootstrap Header -->
    <header>
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
            <a class="navbar-brand d-flex align-items-center" href="dashboard.html">
                <img src="assets/img/logo.png" alt="Logo" class="navbar-logo"> PS
            </a>
            <span class="navbar-divider"></span>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item"><a class="nav-link" href="dashboard.php">Beranda</a></li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="transaksiSuratDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Transaksi Surat</a>
                        <div class="dropdown-menu" aria-labelledby="transaksiSuratDropdown">
                            <a class="dropdown-item" href="surat_masuk.php">Surat Masuk</a>
                            <a class="dropdown-item" href="surat_keluar.php">Surat Keluar</a>
                        </div>
                    </li>
                    <li class="nav-item"><a class="nav-link" href="buku_agenda.php">Buku Agenda</a></li>
                    <li class="nav-item"><a class="nav-link" href="galeri_file.php">Galeri File</a></li>
                    <li class="nav-item"><a class="nav-link" href="referensi.php">Referensi</a></li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="pengaturanDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Pengaturan</a>
                        <div class="dropdown-menu" aria-labelledby="pengaturanDropdown">
                            <a class="dropdown-item" href="settings_user.php">User</a>
                        </div>
                    </li>
                </ul>
                <div class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="profilDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <img src="assets/img/iconmonstr-user-5.svg" alt="Profile" class="profile-img"> Administrator
                    </a>
                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="profilDropdown">
                        <a class="dropdown-item" href="administrator.php">Profile</a>
                        <a class="dropdown-item" href="login.php">Logout</a>
                    </div>
                </div>
            </div>
        </nav>
    </header>
    
    <main>
        <section class="letters">
            <h2>Daftar Surat Keluar</h2>
            <button class="btn" onclick="document.getElementById('addLetterForm').style.display='block'">Tambah Surat</button>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Nomor Surat</th>
                        <th>Pengirim</th>
                        <th>Tanggal</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody id="letters-table-body">
                    <!-- nanti data surat nya di display di sini ciess -->
                </tbody>
            </table>
        </section>
        <div id="addLetterForm" class="modal">
            <form id="add-letter-form" class="modal-content animate">
                <span onclick="document.getElementById('addLetterForm').style.display='none'" class="close" title="Close Modal">&times;</span>
                <div class="container">
                    <h2>Tambah Surat Keluar</h2><br>
                    <label for="nomorSurat"><b>Nomor Surat</b></label><br>
                    <input type="text" placeholder="Masukkan Nomor Surat" name="nomorSurat" required><br><br>
                    <label for="pengirim"><b>Pengirim</b></label><br>
                    <input type="text" placeholder="Masukkan Nama Pengirim" name="pengirim" required><br><br>
                    <label for="tanggal"><b>Tanggal</b></label><br>
                    <input type="date" name="tanggal" required><br><br>
                    <button type="submit" class="btn">Simpan</button>
                </div>
            </form>
        </div>

        <!-- konfirmasi ngapus -->
        <div id="confirmDeleteModal" class="modal-confirm">
            <div class="modal-content-confirm">
                <span class="close-confirm" onclick="document.getElementById('confirmDeleteModal').style.display='none'">&times;</span>
                <p>Yakin ingin menghapus surat tersebut?</p><br>
                <button id="confirmDeleteYes" class="btn btn-danger">Iya</button><br><br>
                <button id="confirmDeleteNo" class="btn btn-secondary">Tidak</button>
            </div>
        </div>
    </main>

    <!-- Bootstrap Footer  -->
    <footer>
        <div class="card footer-card">
            <h5 class="card-header">Pengelolaan Surat</h5>
            <div class="card-body">
                <h5 class="card-title">Selamat Datang</h5>
                <p>&copy; 2024 Universitas Lampung || Letter Head</p>
                <p class="text-card">Kelola surat menyurat Anda dengan mudah dan efisien.</p>
                <a href="#" class="btn btn-primary">Pelajari Lebih Lanjut</a>
            </div>
        </div>
    </footer>
    <script>
        let suratIdToDelete = null;

        window.onclick = function(event) {
            if (event.target == document.getElementById('addLetterForm')) {
                document.getElementById('addLetterForm').style.display = "none";
            }
        }

        document.getElementById('add-letter-form').addEventListener('submit', function(e) {
            e.preventDefault();
            var formData = new FormData(this);

            fetch('tambah_surat_keluar.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert(data.message);
                    document.getElementById('addLetterForm').style.display = 'none';
                    loadSuratMasuk();
                } else {
                    alert(data.message);
                }
            })
            .catch(error => console.error('Error:', error));
        });

        function loadSuratMasuk() {
            fetch('get_surat_keluar.php')
                .then(response => response.json())
                .then(data => {
                    var tbody = document.getElementById('letters-table-body');
                    tbody.innerHTML = '';
                    data.forEach(function(item) {
                        var row = `<tr>
                            <td>${item.nomor_surat}</td>
                            <td>${item.pengirim}</td>
                            <td>${item.tanggal}</td>
                            <td><button class="btn btn-danger" onclick="confirmDelete(${item.id})">Hapus</button></td>
                        </tr>`;
                        tbody.innerHTML += row;
                    });
                })
                .catch(error => console.error('Error:', error));
        }

        function confirmDelete(id) {
            suratIdToDelete = id;
            document.getElementById('confirmDeleteModal').style.display = 'block';
        }

        document.getElementById('confirmDeleteYes').addEventListener('click', function() {
            fetch('delete_surat_keluar.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ id: suratIdToDelete })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert(data.message);
                    loadSuratMasuk();
                } else {
                    alert(data.message);
                }
                document.getElementById('confirmDeleteModal').style.display = 'none';
            })
            .catch(error => console.error('Error:', error));
        });

        document.getElementById('confirmDeleteNo').addEventListener('click', function() {
            document.getElementById('confirmDeleteModal').style.display = 'none';
        });

        document.addEventListener('DOMContentLoaded', function() {
            loadSuratMasuk();
        });
    </script>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>