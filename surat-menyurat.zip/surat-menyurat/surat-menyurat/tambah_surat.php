<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "web_uap";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$response = array('success' => false, 'message' => '');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nomor_surat = $_POST['nomorSurat'];
    $pengirim = $_POST['pengirim'];
    $tanggal = $_POST['tanggal'];

    $sql = "INSERT INTO surat_yang_ditambah (nomor_surat, pengirim, tanggal) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $nomor_surat, $pengirim, $tanggal);

    if ($stmt->execute()) {
        $response['success'] = true;
        $response['message'] = "Berhasil menambahkan surat!";
    } else {
        $response['message'] = "Error: " . $sql . "<br>" . $conn->error;
    }

    $stmt->close();
}

$conn->close();

header('Content-Type: application/json');
echo json_encode($response);
?>