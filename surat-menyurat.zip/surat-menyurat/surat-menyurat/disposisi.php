<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Disposisi - Pengelolaan Surat</title>
    <link rel="stylesheet" href="css/materialize.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <!-- Bootstrap Header -->
    <header>
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
            <a class="navbar-brand d-flex align-items-center" href="dashboard.html">
                <img src="assets/img/logo.png" alt="Logo" class="navbar-logo"> PS
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item"><a class="nav-link" href="dashboard.html">Beranda</a></li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="transaksiSuratDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Transaksi Surat</a>
                        <div class="dropdown-menu" aria-labelledby="transaksiSuratDropdown">
                            <a class="dropdown-item" href="surat_masuk.html">Surat Masuk</a>
                            <a class="dropdown-item" href="surat_keluar.html">Surat Keluar</a>
                        </div>
                    </li>
                    <li class="nav-item"><a class="nav-link" href="buku_agenda.html">Buku Agenda</a></li>
                    <li class="nav-item"><a class="nav-link" href="galeri_file.html">Galeri File</a></li>
                    <li class="nav-item"><a class="nav-link" href="referensi.html">Referensi</a></li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="pengaturanDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Pengaturan</a>
                        <div class="dropdown-menu" aria-labelledby="pengaturanDropdown">
                            <a class="dropdown-item" href="settings_user.html">User</a>
                        </div>
                    </li>
                </ul>
                <div class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="profilDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <img src="assets/img/iconmonstr-user-5.svg" alt="Profile" class="profile-img"> Administrator
                    </a>
                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="profilDropdown">
                        <a class="dropdown-item" href="administrator.html">Profile</a>
                        <a class="dropdown-item" href="logout.html">Logout</a>
                    </div>
                </div>
            </div>
        </nav>
    </header>
    <main>
        <section class="dispositions">
            <h2>Daftar Disposisi</h2>
            <button class="btn" onclick="document.getElementById('addDispositionForm').style.display='block'">Tambah Disposisi</button>
            <table>
                <thead>
                    <tr>
                        <th>Nomor Disposisi</th>
                        <th>Surat Terkait</th>
                        <th>Tanggal</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>001/D/2024</td>
                        <td>001/SM/2024</td>
                        <td>03/01/2024</td>
                        <td><button class="btn">View</button></td>
                    </tr>
                    <!-- Additional rows as needed -->
                </tbody>
            </table>
        </section>
        <div id="addDispositionForm" class="modal">
            <form class="modal-content animate">
                <span onclick="document.getElementById('addDispositionForm').style.display='none'" class="close" title="Close Modal">&times;</span>
                <div class="container">
                    <h2>Tambah Disposisi</h2>
                    <label for="nomorDisposisi"><b>Nomor Disposisi</b></label>
                    <input type="text" placeholder="Masukkan Nomor Disposisi" name="nomorDisposisi" required>
                    <label for="suratTerkait"><b>Surat Terkait</b></label>
                    <input type="text" placeholder="Masukkan Nomor Surat Terkait" name="suratTerkait" required>
                    <label for="tanggal"><b>Tanggal</b></label>
                    <input type="date" name="tanggal" required>
                    <button type="submit" class="btn">Simpan</button>
                </div>
            </form>
        </div>
    </main>

    <!-- Bootstrap Footer  -->
    <footer>
        <div class="card footer-card">
            <h5 class="card-header">Pengelolaan Surat</h5>
            <div class="card-body">
                <h5 class="card-title">Selamat Datang</h5>
                <p>&copy; 2024 Universitas Lampung || Letter Head</p>
                <p class="text-card">Kelola surat menyurat Anda dengan mudah dan efisien.</p>
                <a href="#" class="btn btn-primary">Pelajari Lebih Lanjut</a>
            </div>
        </div>
    </footer>
    <script>
        window.onclick = function(event) {
            if (event.target == document.getElementById('addDispositionForm')) {
                document.getElementById('addDispositionForm').style.display = "none";
            }
        }
    </script>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>