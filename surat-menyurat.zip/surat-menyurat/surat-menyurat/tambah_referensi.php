<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "web_uap";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$response = array('success' => false, 'message' => '');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $judul = $_POST['judul'];
    $penulis = $_POST['penulis'];
    $tahun = $_POST['tahun'];

    $sql = "INSERT INTO referensi (judul, penulis, tahun) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $judul, $penulis, $tahun);

    if ($stmt->execute()) {
        $response['success'] = true;
        $response['message'] = "Berhasil menambahkan Referensi!";
    } else {
        $response['message'] = "Error: " . $sql . "<br>" . $conn->error;
    }

    $stmt->close();
}

$conn->close();

header('Content-Type: application/json');
echo json_encode($response);
?>