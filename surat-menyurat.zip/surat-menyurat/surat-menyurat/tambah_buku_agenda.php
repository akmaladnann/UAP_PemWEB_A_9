<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "web_uap";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$response = array('success' => false, 'message' => '');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nomor_agenda = $_POST['nomor_agenda'];
    $deskripsi = $_POST['deskripsi'];
    $tanggal = $_POST['tanggal'];

    $sql = "INSERT INTO buku_agenda (nomor_agenda, deskripsi, tanggal) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $nomor_agenda, $deskripsi, $tanggal);

    if ($stmt->execute()) {
        $response['success'] = true;
        $response['message'] = "Berhasil menambahkan Buku Agenda!";
    } else {
        $response['message'] = "Error: " . $sql . "<br>" . $conn->error;
    }

    $stmt->close();
}

$conn->close();

header('Content-Type: application/json');
echo json_encode($response);
?>