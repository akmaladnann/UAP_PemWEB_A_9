<?php
session_start();

// Lakukan koneksi ke database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "web_uap";

$conn = new mysqli($servername, $username, $password, $dbname);

// Periksa koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Ambil data yang dikirimkan melalui form login
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Lakukan query ke database untuk mencari username yang cocok
    $query = "SELECT * FROM master_admin WHERE username = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        // Jika username ditemukan, verifikasi password
        $row = $result->fetch_assoc();
        if (password_verify($password, $row['password'])) {
            // Login berhasil, set session dan arahkan pengguna ke dashboard
            $_SESSION['username'] = $username;
            header("Location: dashboard.php");
            exit();
        } else {
            // Jika password tidak cocok, tampilkan pesan kesalahan
            $alert_message = "Password yang Anda masukkan salah!";
        }
    } else {
        // Jika username tidak ditemukan, tampilkan pesan kesalahan
        $alert_message = "Username tidak ditemukan!";
    }
    $stmt->close();
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Pengelolaan Surat</title>
    <link rel="stylesheet" href="css/materialize.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <div class="login-box">
            <h1>Pengelolaan Surat</h1>
            <img src="assets/img/logo.png" alt="Logo" class="logo">
            <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <div class="input-field">
                    <label for="username">Nama Pengguna</label>
                    <input type="text" name="username" id="username" required>
                </div>
                <div class="input-field">
                    <label for="password">Kata Sandi</label>
                    <input type="password" name="password" id="password" required>
                </div>
                <button type="submit" class="btn">Masuk</button>
            </form>
            <?php if (isset($alert_message)) { ?>
                <div id="alert-message" class="error">
                    <p><?php echo $alert_message; ?></p>
                </div>
            <?php } ?>
        </div>
    </div>

    <script>
        function login() {
            var username = document.getElementById('username').value;
            var password = document.getElementById('password').value;
            var alertMessage = document.getElementById('alert-message');

            if (username === "" || password === "") {
                window.location.href = "dashboard.php";                
            } else {
                alertMessage.style.display = 'block';
            }
        }
    </script>
</body>
</html>
