<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "web_uap";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$error_message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $username = $_POST['username'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM adminn WHERE email = '$email' AND username = '$username' AND password = '$password'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $_SESSION['username'] = $username; 
        header("Location: dashboard.php");
        exit();
    } else {
        $error_message = "Harap masukkan data yang valid!";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Pengelolaan Surat</title>
    <link rel="stylesheet" href="css/materialize.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <div class="login-box">
            <h1>Pengelolaan Surat</h1>
            <img src="assets/img/logo.png" alt="Logo" class="logo">
            <form method="post" action="login.php">
                <div class="input-field">
                    <label for="email">Email</label>
                    <input type="email" name="email" id="email" required>
                </div>
                <div class="input-field">
                    <label for="username">Nama Pengguna</label>
                    <input type="text" name="username" id="username" required>
                </div>
                <div class="input-field">
                    <label for="password">Kata Sandi</label>
                    <input type="password" name="password" id="password" required>
                </div>
                <button type="submit" class="btn">Masuk</button>
            </form>
            <?php if ($error_message != ""): ?>
                <div id="alert-message" class="alert alert-danger mt-3">
                    <p><?php echo $error_message; ?></p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>